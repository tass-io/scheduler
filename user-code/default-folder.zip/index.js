var tool = require("./tool/tool")

console.log(tool.test())
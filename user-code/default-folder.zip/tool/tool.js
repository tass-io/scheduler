exports.test = function test() {
    return "test in tool"
}